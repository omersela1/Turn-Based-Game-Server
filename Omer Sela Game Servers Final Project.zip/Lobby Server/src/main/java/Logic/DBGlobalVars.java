package Logic;

public class DBGlobalVars
{
	public String id;
	public String varName;
	public String varVersion;
	public String varData;
	
	public DBGlobalVars(String _Id,String _VarName,String _VarVersion,String _VarData)
	{
		id = _Id;
		varName = _VarName;
		varVersion = _VarVersion;
		varData = _VarData;
	}
}
