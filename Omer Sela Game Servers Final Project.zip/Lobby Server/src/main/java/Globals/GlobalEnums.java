package Globals;

public class GlobalEnums
{
	public enum serverEnvironment
	{
		Local, Development, Production
	};
}

