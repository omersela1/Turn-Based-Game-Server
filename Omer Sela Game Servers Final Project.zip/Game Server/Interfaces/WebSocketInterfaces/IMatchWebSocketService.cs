﻿namespace TicTacToeGameServer.Interfaces.WebSocketInterfaces
{
    public interface IMatchWebSocketService
    {
        void Start();
        void Stop();
    }
}
